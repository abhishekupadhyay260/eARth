/*     INFINITY CODE 2013-2019      */
/*   http://www.infinity-code.com   */

using UnityEditor;

[CustomEditor(typeof(OnlineMapsTextureControl), true)]
public class OnlineMapsTextureControlEditor : OnlineMapsControlBase3DEditor<OnlineMapsTextureControl>
{

}
